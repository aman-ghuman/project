 <?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";





// Create database
/*$sql = "CREATE DATABASE c0709279_amanpreet";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}*/


// use database
$sql = "USE c0709279_amanpreet";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}


 //sql to create table
$sql = "CREATE TABLE Emp (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Name VARCHAR(50) NOT NULL,
Gender VARCHAR(50) NOT NULL,
Address VARCHAR(50),
Birth_date TIMESTAMP,
City VARCHAR(50),
Province VARCHAR(50),
Postalcode VARCHAR(50),
EmailAddress VARCHAR(50),
WebsiteLink VARCHAR(50),
JoiningDate TIMESTAMP,
AnnualBasicPay FLOAT
)";

if ($conn->query($sql) === TRUE) {
    echo "Table Emp created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}



//$sql = "INSERT INTO Emp(Name,Gender)
//VALUES('7c0709279_amampreet','Female')";
/*$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('1','veerpal','Female','17 academy drive','1995/02/10','Brampton','Ontario','1A1A1A' , 'kaur16133@gmail.com', 'www.fb.com', '2017/04/10','5000')";

$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('2','Aman','Female','17 sea cres drive','1995/05/14','Brampton','Ontario','1C1A1B' , 'aman@gmail.com', 'www.w3school.com', '2017/08/16','8000')";

$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('3','Lovepreet','Female','19 parkside drive','1995/06/19','toronto','Ontario','2C4B6K' , 'lavi@gmail.com', 'www.yahoo.com', '2015/09/16','9000')";

$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('4','jaspreet','Female','19 avenue drive','1995/07/18','toronto','Ontario','2G4G6K' , 'jassi@gmail.com', 'www.gmail.com', '2015/05/16','6000')";


$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('5','ravneet','Female','19 englinton drive','1990/06/17','toronto','Ontario','L6P2C3' , 'ravi@gmail.com', 'www.org.com', '2014/04/15','4000')";


$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('8','ram','Female','15 paleshi drive','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";*/


$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('17','manjit','Female','15 paleshi drive','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";


$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('21','kamal','Female','33 smitther drive','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";

$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('23','palwinder','Female','malta','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";


$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('25','rajinder','Female','ray lawson drive','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";

$sql = "INSERT INTO Emp(id,Name,Gender,Address,Birth_Date,City,Province,Postalcode,EmailAddress,WebsiteLink,JoiningDate,AnnualBasicPay)
VALUES('26','rajinder','Female','ray lawson drive','1990/06/17','toronto','Ontario','L6P2C3' , 'guri@gmail.com', 'www.chatr.com', '2016/09/15','3000')";


























if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$conn->close();
?>