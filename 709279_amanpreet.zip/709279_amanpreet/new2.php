<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "c0709279_amanpreet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['update'])){
	$UpdateQuery = "UPDATE Employee SET id='$_POST[Id]', Name='$_POST[name]', Gender='$_POST[gender]' WHERE id='$_POST[hidden]'";
	mysql_query($UpdateQuery,$conn);
	
};


	if(isset($_POST['delete'])){
	$DeleteQuery = "DELETE FROM Employee  WHERE id='$_POST[hidden]'";
	mysql_query($DeleteQuery,$conn);


	};


	
	
	
	//mysql_select_db("c0709279_amanpreet",$conn);
$sql = "SELECT * FROM Emp";
//$myData = mysql_query($sql,$conn);
$result = $conn->query($sql);



//if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Gender</th>
	<th>Address</th>
	<th>Birth_date</th>
	<th>City</th>
	<th>Province</th>
	<th>Postalcode</th>
	<th>EmailAddress</th>
	<th>WebsiteLink</th>
	<th>JoiningDate</th>
	<th>AnnualBasicPay</th>
	</tr>";

    while($row = $result->fetch_assoc()) {
		echo "<form action=new1.php method=post>";
		echo "<tr>";
		echo "<td>" . "<input type=text name=Id value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=text name=name value=" . $row['Name'] . " </td>";
		echo "<td>" . "<input type=text name=gender value=" . $row['Gender'] . " </td>";
		echo "<td>" . "<input type=text name=add value=" . $row['Address'] . " </td>";
		echo "<td>" . "<input type=text name=brthdate value=" . $row['Birth_date'] . " </td>";
		echo "<td>" . "<input type=text name=city value=" . $row['City'] . " </td>";
		echo "<td>" . "<input type=text name=province value=" . $row['Province'] . " </td>";
		echo "<td>" . "<input type=text name=postalcode value=" . $row['Postalcode'] . " </td>";
		echo "<td>" . "<input type=text name=emailadd value=" . $row['EmailAddress'] . " </td>";
		echo "<td>" . "<input type=text name=wblnk value=" . $row['WebsiteLink'] . " </td>";
	    echo "<td>" . "<input type=text name=jndate  value=" . $row['JoiningDate'] . " </td>";
		echo "<td>" . "<input type=text name=annualbacpay value=" . $row['AnnualBasicPay'] . " </td>";
				
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	    echo "<td>" . "<input type=hidden name=hidden value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=submit name=update value=update" . " </td>";
			echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
			echo "</tr>";
		
		
     echo "</form>";   
    }
    echo "</table>";
/*else {
 //  echo "0 results";
//}
*/
$conn->close();
?>